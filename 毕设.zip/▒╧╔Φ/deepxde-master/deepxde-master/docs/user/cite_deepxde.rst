Cite DeepXDE
============

If you use DeepXDE for academic research, you are encouraged to cite the following paper::

  @article{lu2019deepxde,
    author  = {Lu, Lu and Meng, Xuhui and Mao, Zhiping and Karniadakis, George E.},
    title   = {{DeepXDE}: A deep learning library for solving differential equations},
    journal = {arXiv preprint arXiv:1907.04502},
    year    = {2019}
  }
