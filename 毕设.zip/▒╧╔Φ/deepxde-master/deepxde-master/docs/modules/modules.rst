API
=======

.. toctree::
   :maxdepth: 2

   deepxde
   deepxde.data
   deepxde.geometry
   deepxde.maps
